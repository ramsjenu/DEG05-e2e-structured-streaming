from kafka.oauth.abstract import AbstractTokenProvider
