import sys

from importlib.metadata import version


__version__ = version("kafka-python-ng")
