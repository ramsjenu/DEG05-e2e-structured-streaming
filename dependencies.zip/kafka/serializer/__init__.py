from kafka.serializer.abstract import Serializer, Deserializer
